if [ ! -f /data/data/com.itsaky.androidide/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.itsaky.androidide/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.itsaky.androidide/files/home/.termux
	cp /data/data/com.itsaky.androidide/files/usr/share/examples/termux/termux.properties /data/data/com.itsaky.androidide/files/home/.termux/
fi
