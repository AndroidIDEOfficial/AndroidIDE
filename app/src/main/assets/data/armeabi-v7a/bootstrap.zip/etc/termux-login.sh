##
## This script is sourced by /data/data/com.itsaky.androidide/files/sysroot/bin/login before executing shell.
##
