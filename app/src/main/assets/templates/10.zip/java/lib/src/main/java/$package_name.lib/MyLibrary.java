package $package_name.lib;

public class MyLibrary {
    private String text = "Hello from library";
    
    public String getText(){
        return text;
    }
}
