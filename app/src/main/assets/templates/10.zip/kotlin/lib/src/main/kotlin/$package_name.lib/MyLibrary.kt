package $package_name.lib

class MyLibrary {
    
    companion object {
        val text = "Hello from library"
    }
}
