package $package_name;

import android.content.Context;
import android.hardware.camera2.CameraManager;
import android.os.*;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.itsaky.androidide.logsender.LogSender;
import $package_name.R;

public class MainActivity extends AppCompatActivity {
    
    private boolean flashState;
    private Button btnFlash;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
		// Remove this line if you don't want AndroidIDE to show this app's logs
		LogSender.startLogging(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        btnFlash = findViewById(R.id.btnLight);
        
        btnFlash.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                try {
                    CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                    String cameraID = cameraManager.getCameraIdList()[0];
                    
                	if (flashState) {
                    	cameraManager.setTorchMode(cameraID, false);
                    	btnFlash.setText(R.string.flash_off);
                        flashState = false;
                	} else {
                		cameraManager.setTorchMode(cameraID, true);
                    	btnFlash.setText(R.string.flash_on);
                        flashState = true;
                	}
                } catch (android.hardware.camera2.CameraAccessException e) {
                	Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}