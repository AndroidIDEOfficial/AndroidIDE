package $package_name;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import $package_name.R;

public class RegisterActivity extends AppCompatActivity {
    
    private EditText edtUsername;
    private EditText edtEmail;
    private EditText edtPass;
    private Button btnReturn;
    private Button btnRegister;
    private String username;
    private String email;
    private String password;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_activity);
        
        edtUsername = findViewById(R.id.edtUsername);
        edtEmail = findViewById(R.id.edtEmail);
        edtPass = findViewById(R.id.edtPass);
        btnReturn = findViewById(R.id.btnReturn);
        btnRegister = findViewById(R.id.btnRegister);
        
        btnRegister.setOnClickListener(new View.OnClickListener() {
        	@Override
            public void onClick(View view) {
                username = edtUsername.getText().toString();
                email = edtEmail.getText().toString();
                password = edtPass.getText().toString();
                
                if (validateInfo(username, email, password)) {
                    registerAccount(username, email, password);
                } else {
                	Toast.makeText(getApplicationContext(), "Complete all the fields correctly", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    
    public void registerAccount(String username, String email, String password) {
    	// Write your code
    }
    public boolean validateInfo(String username, String email, String password) {
    	if (username != "" && email != "" && password != "") {
        	if (username.length() > 5 && email.length() > 6 && password.length() < 7) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
