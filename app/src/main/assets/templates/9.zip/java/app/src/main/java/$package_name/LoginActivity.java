package $package_name;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import $package_name.R;
import $package_name.RegisterActivity;

public class LoginActivity extends AppCompatActivity {
    
    private Button btnRegister;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        
        btnRegister = findViewById(R.id.btnRegister);
        
        // Set Screen to "RegisterActivity"
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent screen = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(screen);
            }
        });
    }
    
    public void Login(String email, String password) {
        //
    }
}