package $package_name;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import $package_name.R;

public class LoginActivity extends AppCompatActivity {
    
    private EditText edtEmail;
    private EditText edtPass;
    private Button btnLogin;
    private Button btnRegister;
    private String login;
    private String password;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        
        edtEmail = findViewById(R.id.edtEmail);
        edtPass = findViewById(R.id.edtPass);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        
        // continue your code here...
        
    }
    // Create the function to Login
    public void Login(String email, String passsword) {
        // enter your code here
    }
    
    // Create a function to Register
    public void Register(String email, String password) {
        // enter your code here
    }
    
    // Create a function to check
    public void isSaveLogin(boolean isChecked) {
        // enter your code here
    }
}