package $package_name

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.content.Context
import android.widget.Toast
import android.widget.Button
import android.widget.EditText
import com.itsaky.androidide.logsender.LogSender

import $package_name.R

public class LoginActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        // Remove this line if you don't want AndroidIDE to show this app's logs
        LogSender.startLogging(this@LoginActivity)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)
        
        //your code here...
    }
    
    fun Login(email: String, password: String) {
        // your code here
    }
    
    fun Register(email: String, password: String) {
        // your code here
    }
    
    fun isLoginSaved(isClicked: Boolean) {
        // your code here
    }
}