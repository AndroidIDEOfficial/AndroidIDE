package $package_name

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.view.View
import android.os.Bundle
import android.util.Log
import android.content.Context
import android.widget.Toast
import android.widget.Button
import android.widget.EditText
import com.itsaky.androidide.logsender.LogSender

import $package_name.R

public class RegisterActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        // Remove this line if you don't want AndroidIDE to show this app's logs
        LogSender.startLogging(this@RegisterActivity)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_activity)
        
        val btnReturn: Button = findViewById(R.id.btnReturn)
        
        btnReturn.setOnClickListener{
            finish()
        }
    }
    
    fun Register(username: String, email: String, password: String) {
        // write your code...
    }
}