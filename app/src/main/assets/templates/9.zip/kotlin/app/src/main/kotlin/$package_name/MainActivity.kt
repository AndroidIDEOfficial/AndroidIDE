package $package_name

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.util.Log
import android.content.Context
import android.widget.Toast
import android.widget.Button
import android.widget.EditText
import com.itsaky.androidide.logsender.LogSender

import $package_name.R

public class MainActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        // Remove this line if you don't want AndroidIDE to show this app's logs
        LogSender.startLogging(this@MainActivity)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        val btnSetScreen: Button = findViewById(R.id.btnSetScreen)
        
        btnSetScreen.setOnClickListener {
            val screen: Intent = Intent(this, LoginActivity::class.java)
            startActivity(screen)
        }
    }
}